import './assets/background.js-Bcimxdbb.js';
